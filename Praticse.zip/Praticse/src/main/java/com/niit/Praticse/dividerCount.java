package com.niit.Praticse;

import java.util.Scanner;

public class dividerCount {

	public static void main(String[] args) {
		int count=0;
		System.out.println("enter the value of l");
		Scanner scn1=new Scanner(System.in);
		int l=scn1.nextInt();
		System.out.println("enter the value of r");
		Scanner scn2=new Scanner(System.in);
		int r=scn2.nextInt();
		System.out.println("enter the value of k");
		Scanner scn3=new Scanner(System.in);
		int k=scn3.nextInt();
		
		for(int i=l;i<=r;i++)
		{
			if(i%k==0)
			{
				count++;
			}
			
		}
		
		System.out.println("total count:"+count);

	}

}
