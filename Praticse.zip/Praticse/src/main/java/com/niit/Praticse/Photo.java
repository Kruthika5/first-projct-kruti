package com.niit.Praticse;

import java.util.Scanner;

public class Photo {

	public static void main(String[] args) {
		System.out.println("enter the value of l");
		Scanner scn1=new Scanner(System.in);
		int l=scn1.nextInt();
		System.out.println("enter the value of w");
		Scanner scn2=new Scanner(System.in);
		int w=scn2.nextInt();
		System.out.println("enter the value of h");
		Scanner scn3=new Scanner(System.in);
		int h=scn1.nextInt();
		
		int a=l*l;
		int n=w*h;
		if(n==a){
			System.out.println("accepted");
			
		}
		else if(w!=l||h!=l)
		{
			System.out.println("change photo ");
		}
		
		else
		{
			System.out.println("crop");
		}
	}

}
