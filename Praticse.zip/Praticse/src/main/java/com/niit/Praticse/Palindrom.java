package com.niit.Praticse;

public class Palindrom {

	public static void main(String[] args) {
	 StringBuffer s1= new StringBuffer("KruthikaakihturK");
	 StringBuffer s2=new StringBuffer(s1);
	 s1.reverse();
	 System.out.println("given string:"+s1);
	 System.out.println("reverse string:"+s2);
	 if(String.valueOf(s1).compareTo(String.valueOf(s2))==0)
	 
      System.out.println("\"yes\"");
	 else
		 System.out.println("\"no\"");
	}
}

		
		 
			 
		 
	 
	 
		
		
		
