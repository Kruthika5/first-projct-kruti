package com.niit.Praticse;

import java.util.Scanner;

public class NumberBreak {

	public static void main(String[] args) {
		//System.out.println("enter the number");
		//Scanner scn=new Scanner(System.in);
	int a[]={1,2,88,42,99};
	int i;
	int b=a.length;
	for(i=0;i<b;i++){
		System.out.println(a[i]);
		
			if(a[i]==42)
				break;
			
		}


	}
	
}

