package com.niit.Praticse;

import java.util.Scanner;

public class convert {

	public static void main(String[] args) {
		int l,i;
		char c;
		System.out.println("enter the string");
		Scanner scn=new Scanner(System.in);
		String n=scn.next();
		l=n.length();
		for(i=0;i<l;i++)
		{
			c=n.charAt(i);
			if(Character.isUpperCase(c))
				System.out.print(Character.toLowerCase(c));
			else if(Character.isLowerCase(c))
				System.out.print(Character.toUpperCase(c));
			else
			System.out.print(c);
			
			
		}
		System.out.println("\nlenght:"+l);
		
		System.out.println(n.toUpperCase());
		System.out.println(n.toLowerCase());
		
		
	}

	

}