package com.niit.Praticse;

public class multiple {

	public static void main(String[] args) {
		int a[]={2,3};
		int b=1;
		int l=a.length;
		for(int i=0;i<l;i++){
			b=b*a[i];
			
		}
		System.out.println(b);
	}

}
