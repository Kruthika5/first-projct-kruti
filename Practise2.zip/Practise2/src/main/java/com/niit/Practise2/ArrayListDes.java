package com.niit.Practise2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ArrayListDes {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		
		al.add("arun");
		al.add("sanju");
		al.add("arul");
		
		System.out.println("before decsending:");
		
		Iterator itr=al.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
			
			
		}

		Collections.sort(al,Collections.reverseOrder());
		System.out.println(" ");
		System.out.println("after decsending:");
		Iterator itr1=al.iterator();
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());
			
			
		}
		
		Collections.sort(al);
		System.out.println(" ");
		System.out.println("after acsending:");
		
		Iterator itr2=al.iterator();
		while(itr2.hasNext())
		{
			System.out.println(itr2.next());
			
			
		}
		
	}

}
