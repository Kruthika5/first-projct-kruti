package com.niit.Practise2;

import java.util.HashSet;

public class Hashset {

	public static void main(String[] args) {
		HashSet h=new HashSet();
	
		h.add("vasavi");
		h.add("dishu");
		h.add("sathi");
		
		System.out.println("size of hashset:"+h.size());
		System.out.println(" ");
		
		
		//to object array
		 Object[] o1=h.toArray();
		 for(int i=0; i < o1.length ; i++)
		      System.out.println(o1[i]);
		 
		 System.out.println(" ");
		 
		
		 
		 //to string array 
		 String[] strArr = new String[h.size()];
	        h.toArray(strArr);
	        for(int i=0; i < strArr.length ; i++)
			      System.out.println(o1[i]);
	        
	      
	        
	        
	        //by using for each loop
		System.out.println(" ");
	        for(String strr: strArr){
	        	System.out.println(strr);
	        }
		
	}
	
		

	

}
