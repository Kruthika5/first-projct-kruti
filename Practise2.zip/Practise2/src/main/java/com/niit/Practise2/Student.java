package com.niit.Practise2;

import java.util.ArrayList;
import java.util.Iterator;

public class Student {
	
	 int id;
	 String name;
     String address;
	
	Student(int id,String name,String address){
		this.id=id;
		this.name=name;
		this.address=address;
		
	}
	
	

}
