package com.niit.Practise2;

import java.util.ArrayList;

import java.util.Collections;
import java.util.List;

public class Max {

	public static void main(String[] args) {
		List<Integer> li=new ArrayList<Integer>();
		li.add(34);
		li.add(2);
		li.add(56);
		System.out.println("Max element in list:"+Collections.max(li));
		

	}

}
