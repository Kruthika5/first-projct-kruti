package com.niit.Practise2;

import java.util.Iterator;
import java.util.TreeSet;

public class Treeset {

	public static void main(String[] args) {
	TreeSet t=new TreeSet();
	
	t.add(2);
	t.add(5);
	t.add(1);
	t.add(3);
	t.add(4);
	
	Iterator itr=t.iterator();
	
	while(itr.hasNext())
	{
		System.out.print(itr.next()+" ");
	}
	
	System.out.println(" ");
	
	System.out.println("\nLowest value Stored in Java TreeSet is : " + t.first());
	
	 System.out.println("\nHighest value Stored in Java TreeSet is : " + t.last());
	}

}
