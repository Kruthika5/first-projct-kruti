package com.niit.Practise2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;

public class Linklist {

	public static void main(String[] args) {
		List<String> l=new ArrayList<String>();
		
		l.add("java");
		l.add("disha");
		l.add("java");
		l.add("sanju");
		l.add("sanju");
		System.out.println("before duplication"+l);
		
		LinkedHashSet<String> h=new LinkedHashSet<String>();
		h.addAll(l);
		l.clear();
		l.addAll(h);
		
		System.out.println("after duplication"+l);

		
	}

}
