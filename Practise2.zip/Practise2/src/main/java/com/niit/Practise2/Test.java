package com.niit.Practise2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
public class Test {

	public static void main(String[] args) {
		Student s1=new Student(1, "sanju", "#47");
		Student s2=new Student(2, "arul", "#48");
		Student s3=new Student(3, "arul", "#49");
		
		
		ArrayList<Student> al=new ArrayList<Student>();
		
		al.add(s1);
		al.add(s2);
		al.add(s3);
		
		System.out.println("before descending:");
		
		Iterator itr=al.iterator();
		
		while(itr.hasNext())
		
		{
			Student st=(Student)itr.next();
			System.out.println(st.id+" "+st.name+" "+st.address);
			
		}
		
		System.out.println("before ascending:");
		
		Collections.sort(al,new Camp());
		
		Iterator itr1=al.iterator();
	
		while(itr1.hasNext())
			
		{
			Student st=(Student)itr1.next();
			System.out.println(st.id+" "+st.name+" "+st.address);
			
		}
		
		
			

	}

}
