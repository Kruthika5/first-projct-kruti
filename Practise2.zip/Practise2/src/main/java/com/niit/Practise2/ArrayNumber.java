package com.niit.Practise2;

import java.util.ArrayList;

public class ArrayNumber {

	public static void main(String[] args) {
		ArrayList<Object> d=new ArrayList<Object>();
		
		d.add('a');
		d.add("aruna");
		d.add('a');
		d.add('b');
		d.add("java");
		d.add("rava");
		d.add("anjan");
		
		int l=d.size();
		
   System.out.println("Number of elements in list:"+l);
	}

}
