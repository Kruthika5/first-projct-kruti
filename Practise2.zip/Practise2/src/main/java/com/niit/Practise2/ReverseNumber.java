package com.niit.Practise2;

import java.util.Scanner;

public class ReverseNumber {
   
	public static void main(String[] args) {
		 int rev=0;
	Scanner scn=new Scanner(System.in);
	System.out.println("Enter a 4 digit number");
	int l=scn.nextInt();
	do{
		int rem=l%10;
		rev=(rev*10)+rem;
		l=l/10;
		
	}while(l!=0);
	System.out.println("the reverse number :"+rev);

	}

}
