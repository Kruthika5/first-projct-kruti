package com.niit.Practise2;

import java.util.HashMap;

public class hashmap {

	public static void main(String[] args) {
		HashMap hmap=new HashMap();
		
		hmap.put(1,"arun");
		hmap.put(2, "arul");
		hmap.put(3,"sanju");
		
		System.out.println("before removing the element:"+hmap);
		if(hmap.containsKey(1))
			System.out.println("it exit:"+hmap.get(1));
		else
			System.out.println("it doesnt exist");
			
		
		hmap.remove(2);
		
		System.out.println("after removing the element:"+hmap);
		


	}

}
