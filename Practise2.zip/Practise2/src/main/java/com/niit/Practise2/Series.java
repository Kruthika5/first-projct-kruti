package com.niit.Practise2;

import java.util.Scanner;

public class Series {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
        int i , n, x;
        double res;
		double sum=0;
        System.out.println("Enter the value of n");
        n = in.nextInt();
        System.out.println("Enter the value of x");
        x = in.nextInt();
        for(i = 1; i<= n; i ++)
        {
            res = Math.pow(x, i)/i;
            sum = sum + res;
        }
        System.out.println("The sum is "+sum);
    

	}

}
