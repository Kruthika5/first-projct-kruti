package com.niit.Practise2;

import java.util.ArrayList;

public class Arraylist {

	public static void main(String[] args) {
		int i,j;
	ArrayList<Object> d=new ArrayList<Object>();
	
	d.add("java");
	d.add('a');
	d.add("aruna");
	d.add(3);
	d.add('b');
	d.add("java");
	d.add(3);
	System.out.println("before duplication"+d);
	
	for(i=0;i<d.size();i++){
		for(j=i+1;j<d.size();j++){
			if(d.get(i).equals(d.get(j))){
				d.remove(j);
				j--;
				
			}
		}
		
	}
	System.out.println("after duplication"+d);
		
}

}
