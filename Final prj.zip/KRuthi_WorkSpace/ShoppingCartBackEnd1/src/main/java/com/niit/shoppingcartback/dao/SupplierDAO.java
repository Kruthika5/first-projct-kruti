package com.niit.shoppingcartback.dao;

import java.util.List;

import com.niit.shoppingcartback.model.Supplier;

public interface SupplierDAO {
	public Supplier getSupplier(String id);
	public void saveOrUpdate(Supplier supplier);
	public void delete(String id);
	public Supplier getByName(String name);
	public List<Supplier> list();
}
