package com.niit.shoppingcartback.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartback.dao.CategoryDAO;
import com.niit.shoppingcartback.model.Category;

public class CTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.shoppingcartback");
		context.refresh();
		
		CategoryDAO categoryDAO=(CategoryDAO) context.getBean("categoryDAO"); //Getting categorydao object
		System.out.println("success");
		
		Category category=(Category) context.getBean("category");  //Getting cateogry object
		System.out.println("SUCCESS");
		
	   category.setId("C002");
		category.setName("C002def");
		category.setDescription("C002addr");
		
		//categoryDAO.saveOrUpdate(category);
		
		//categoryDAO.delete("C001");
		
		//System.out.println(categoryDAO.getCategory("C001").getName());
if(   categoryDAO.getCategory("C001") ==null)
		  {
			  System.out.println("Category does not exist");
		  }
		  else
		  {
			  System.out.println("Category exist .. the details are ..");
			  System.out.println();
		  
			
			}

	}
	
	}


