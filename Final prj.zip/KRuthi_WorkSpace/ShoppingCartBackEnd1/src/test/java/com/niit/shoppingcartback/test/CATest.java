package com.niit.shoppingcartback.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.shoppingcartback.dao.CartDAO;
import com.niit.shoppingcartback.model.Cart;



public class CATest {

	public static void main(String[] args) {
		// TODO Auto-generated method stubAnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcartback");
		context.refresh();
		
		CartDAO cartDAO=(CartDAO) context.getBean("cartDAO"); //Getting categorydao object
		System.out.println("success");
		
		Cart cart=(Cart) context.getBean("cart");  //Getting cateogry object
		System.out.println("SUCCESS");
		
		  cart.setId(0);
		 cart.setPrice(100);
		 cart.setProductName("sdfghj");
		 cart.setQuantity("1");
		 cart.setUserID("userID");  //  id should keep session and use the same id
		 cart.setStatus("N");  // 
         
		 cartDAO.saveOrUpdate(cart);
		 
	}

}
