package com.niit.shoppingcartback.test;

import java.io.PushbackInputStream;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartback.dao.UserDAO;
import com.niit.shoppingcartback.model.User;

public class UTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.shoppingcartback");
		context.refresh();
		
		UserDAO userDAO=(UserDAO) context.getBean("userDAO");
		System.out.println("success");
		
		User user=(User) context.getBean("user");
		
		user.setId("U002");
		user.setName("SAIT");
		user.setPassword("SAIT");
		user.setAddress("U002addr");
		user.setMob_no("88888");
		user.setMail("MAIL002");
		user.setAdmin(0);
		
		
		
		//userDAO.saveOrUpdate(user);
		
		//System.out.println(userDAO.getUser("U001").getName());
		if(   userDAO.getUser("U001") ==null)
		  {
			  System.out.println("Category does not exist");
		  }
		  else
		  {
			  System.out.println("Category exist .. the details are ..");
			  System.out.println();
		  }
			

	}

}
