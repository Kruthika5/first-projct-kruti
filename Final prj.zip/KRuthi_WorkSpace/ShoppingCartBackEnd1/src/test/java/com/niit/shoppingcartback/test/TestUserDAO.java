package com.niit.shoppingcartback.test;

public class TestUserDAO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
