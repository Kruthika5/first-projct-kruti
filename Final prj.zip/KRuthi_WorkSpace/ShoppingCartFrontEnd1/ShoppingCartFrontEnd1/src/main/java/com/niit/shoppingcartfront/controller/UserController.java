package com.niit.shoppingcartfront.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcartback.dao.CartDAO;
import com.niit.shoppingcartback.dao.CategoryDAO;
import com.niit.shoppingcartback.dao.UserDAO;
import com.niit.shoppingcartback.model.Cart;
import com.niit.shoppingcartback.model.Category;
import com.niit.shoppingcartback.model.User;

@Controller
public class UserController {
	@Autowired
	private Cart cart;
	
	@Autowired
	private CartDAO cartDAO;
	
	@Autowired
	Category category;
	
	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	User user;
	
	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session){
		
		ModelAndView mv=new ModelAndView("/index");
	    session.setAttribute("category",category);
	    session.setAttribute("categoryList", categoryDAO.list());
		return mv;
		
	}

	/*@RequestMapping("/login")
	public String getLogin(){
		return "login";
	}*/
	@RequestMapping("/contact")
	public String getContact()
	{
		return "contact";
	}
	@RequestMapping("/aboutus")
	public String getAboutus()
	{
		return "aboutus";
	}
	
	@RequestMapping("/Signup")
	public ModelAndView signup(){
			ModelAndView mv=new ModelAndView("/index");
			mv.addObject("user",user);
			mv.addObject("isUserClickedRegisterHere", "true");
			return mv;
		}
		
	/*@RequestMapping("/check")
	public ModelAndView login(@RequestParam(name="name")String name,@RequestParam(name="password")String password){
		ModelAndView mv;
		
		boolean isValidUser=userDAO.isValidUser(name, password);
		
		if(isValidUser){
			
			
			user=userDAO.getUser(name);
			if(user.getAdmin()==1){
				mv=new ModelAndView("/adminHome");
				mv.addObject("message", "welcome admin"+user.getName());
			}
			else{
				mv=new ModelAndView("/Test");
				mv.addObject("message","welcome"+user.getName());
			}
		}
		else{
			mv=new ModelAndView("/Fail");
			mv.addObject("message","Invalid user");
		}
	return mv;
	}
	
	/*@RequestMapping(value="user/register", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute User userDetails){
		userDAO.saveOrUpdate(userDetails);
		ModelAndView mv=new ModelAndView("/index");
		mv.addObject("successMessage", "You Have Successfully Registered");
		return mv;
	}
*/
	
	
	/*@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView login(@RequestParam(value="error",required=true)String error,@RequestParam(value="logout",required=false)String logout){
		ModelAndView model=new ModelAndView();
		if(error!=null){
			System.out.println("ERROR.....");
			model.addObject("error", "Invalid Credentials");
		}
		if(logout!=null){
			System.out.println("LOGOUT.....");
			model.addObject("msg", "You have logged out successfully");
		}
		model.setViewName("login");
		return model;
	}*/
	//not required since we r using spring flow
	/*@RequestMapping(value="user/register", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute User user){
		userDAO.saveOrUpdate(user);
		ModelAndView mv=new ModelAndView("/index");
		mv.addObject("successMessage", "You Have Successfully Registered");
		return mv;
	}
	
	/*@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView mv = new ModelAndView("/index");
		session.invalidate();
		session = request.getSession(true);
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
	
		mv.addObject("logoutMessage", "You successfully logged out");
		mv.addObject("loggedOut", "true");
	
		return mv;
	 }*/
	 /*
     * login method is used to handle user login related functionality
     */
   @RequestMapping(value = "/loginUser")
    public String login(@RequestParam(value="error", required = false) String error, @RequestParam(value="logout",
            required = false) String logout, Model model) {
        if (error!=null) {
        	System.out.println("Error.....");
            model.addAttribute("error", "...Invalid username and password");
        }
        	
        if(logout!=null) {
        	System.out.println("Logout called.....");
            model.addAttribute("msg", "...You have been logged out");
        }

        return "login";
    }
    
    /*
     * userManagement method is used to open user management page.
     */
    @RequestMapping(value = "/user")
    public String userManagement() 
    {
    	System.out.println("USER CALLED.......");
    	return "login";
    }
    
    @RequestMapping(value = "/admin")
    public String adminManagement() 
    {
    	System.out.println("ADMIN CALLED.......");
    	return "adminHome";
    }
    
    @RequestMapping(value="/afterLogin", method = RequestMethod.GET)
    public String afterLogint() 
    {
    	System.out.println("After User Login.......");
    	return "afterLoginUser";
    }
    
    @RequestMapping("/403")
    public String errorPage() 
    {
    	System.out.println("Error......");
    	return "403";
    }
}
